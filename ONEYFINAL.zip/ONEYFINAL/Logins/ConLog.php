<?php


if(isset($_GET['error'])){
	if($_GET['error'] == 1){
            Print 'Debe llenar los campos... ';
	}else if($_GET['error'] == 2){
            Print 'Los datos ingresados son incorrectos.. ';
	}else if($_GET['error'] == 3){
            Print 'No se intente saltar el inicio de sesión';
	} else if ($_GET['error'] == 4){
            Print 'No intentó iniciar sesión';
	}
	unset($_GET['error']);
}

?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
 <title>Bienvenido</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <link rel="shortcut icon" type="image/png" href="../images/SVE1.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel='stylesheet prefetch' href='https://raw.githubusercontent.com/daneden/animate.css/master/animate.css'>
    <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="container">
    <div class="bg-img"></div>
    <div class="header">
        <div class="loading">
            <div class="block"></div>
            <div class="block"></div>
            <div class="block"></div>
            <div class="block"></div>
        </div>
        <center><a href="../HtmlPage.html"><img src="../images/SVE1.png"></a></center>
    </div>
    <div class="main">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <h1 align="center">Bienvenido Consultor</h1>
        <div class="login">
            <form action="../ValCon.php" method="POST">
                <input id="username" name="usercod" required="required" type="text" placeholder="Digite su Usuario" />
                <input id="password" name="passcod" required="required" type="password" placeholder="Digite su Contraseña" />
                <button type="submit" value="Login" />Login</button>
            </form>
        </div>
    </div>
    <div class="footer">
        <div>
            <br>
            <br>
            <br>
            <br>
            <center>
            <img src="../images/LOGO-SENA.jpg">
            <br>
            &copy; Untitled. All rights reserved.
            </center>
            <div>
    <h3 align="center"><font color="#444"><b>
        <?php
        if(isset($_REQUEST['msg'])){
            echo $_REQUEST['msg'];
        }
        ?>
    </b></font></h3>
</div>
        </div>
    </div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>