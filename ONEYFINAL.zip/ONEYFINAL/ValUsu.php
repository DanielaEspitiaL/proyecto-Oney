<?php
      // Se incluye el archivo de conexión a la base de datos.
      include ("conexion.php");
      $Idtra=$_REQUEST['$row[0]'];

      // Se almacenan los datos recibidos en constantes.
      $usser = $_POST['userinst'];
      $password =$_POST['passinst'];

if(isset($_POST['userinst']) and isset($_POST['passinst'])){
      if (empty($_POST['userinst']) or empty($_POST['passinst']) ){
         header('location: Logins/UsuLog.php?error=1');

      } else {
            try {
            // Se realiza la consulta en la base de datos.
                  $result = $conectar -> query ("select * from administrador where usuario ='$usser'
            and clave = '$password'");
      $row = mysqli_fetch_array($result);
            $num = mysqli_num_rows($result);
            // Se verifica que los datos estén correctos y se en cuentran en la base de datos.
      	if($num > 0) {
      		session_start();
               $_SESSION['inst'] = true;
                  header('location: index/Usuario/indexUsuario.php');
               $_SESSION['Id'] = $row[0];
               $_SESSION['Nombres'] = $row[1];
      	}else {
      		header('location: Logins/UsuLog.php?error=2');
      	}
      } catch (Exception $e) {
            echo $e;
      }
      }
}else{
   header('location: Logins/UsuLog.php?error=3');
}



?>
