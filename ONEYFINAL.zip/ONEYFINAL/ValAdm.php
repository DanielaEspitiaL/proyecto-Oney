<?php
      // Se incluye el archivo de conexión a la base de datos.
      include ("conexion.php");

      // Se almacenan los datos recibidos en constantes.
      $USER = $_POST['user'];
      $PASS =$_POST['pass'];
// Se guarda uno de los parámetros ingresados en una session
      session_start();
      $_SESSION['id'] = $USER;
if(isset($_POST['user']) and isset($_POST['pass'])){
      if (empty($_POST['user']) or empty($_POST['pass']) ){
         header('location: AdmLog.php?error=1');

      } else {

            try {

            // Se realiza la consulta en la base de datos.
            $res=$conectar->query("select * from administrador where usuario='$USER'
            and clave='$PASS'");
            $num = mysqli_num_rows($res);
            // Se verifica que los datos estén correctos y se en cuentran en la base de datos.
      	if($num > 0) {
      		session_start();
               $_SESSION['conexion'] = true;

               header('location:index/Administrador/indexAdm.php');
      	}else {
      		header('location: Logins/AdmLog.php?error=2');
      	}
      } catch (\Exception $e) {
            echo $e;
      }
      }
}else{
   header('location: AdmLog.php?error=3');
}



?>
