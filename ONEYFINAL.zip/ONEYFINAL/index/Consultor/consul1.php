<!DOCTYPE html>
<?php
require ('../../conexion.php');
session_start();

if(($_SESSION['coor']<>true)){
  header("Location: ../../Logins/ConLog.php");
}

$ficha = "0";
$v=0;
//Se verifica si se ha pulsado el boton de consulta para que arroje los resultados de la consulta

?>
<html>
      <head>
            <title>ONEY</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <link rel="shortcut icon" type="image/png" href="../../images/SVE1.png">
            <link rel="stylesheet" href="../../assets/css/main.css" />
            <link rel="stylesheet" href="../../assets/css/bootstrap.css" />
            <!-- Se llama a los archivos de javascript para los combobox dinámicos -->
            <script type="text/javascript"  src="../../assets/js/jquery-3.3.1.min.js"></script>
      <!-- Se crea el escript que permite hacer los listbox dinámicos -->
      <!-- Script para traer los datos de los resultados -->

      <!-- Script para traer los datos de los resultados -->
      </head>
      <body class="subpage">
                  <section id="One" class="wrapper style3">
                        <div class="inner">
                              <header class="align-center">
                                <center><img src="../../images/SVE1.png"></a></center>
                              </header>
                        </div>
                  </section>
                  <script type="text/javascript">
                  $(document).ready(function(){
                        $("#curso").change (function(){
                          $("#encu").find('option').remove().end().append(
                                '<option value="Seleccione un estudiante">Seleccione un estudiante</option>').val('Seleccione un estudiante');

                              //Detecta la opcion seleccionada del listbox de competencias
                              $("#curso option:selected").each(function(){
                                    id_lider = $(this).val();
                              // Envía el código de la competencia al archivo getResultado
                                    $.post("Incluic/lide2.php", { id_lider : id_lider}, function(data){
                                      console.log(data);
                                    // Recibe los datos del archivo y los imprime el el select o listbox
                                          $("#encu").html(data);
                                    })
                              })
                        });
                  });
                  </script>

<!-- Two -->
  <section id="two" class="wrapper style2">
        <div class="inner">
              <div class="box">
                    <div class="content">
                        <header class="align-center">
                                <h2><b><i>Consulta de resultados</i></b></h1>
                        </header>
                        <br>
                        <!-- Formulario para filtrar por competencia, resultado y actividad -->
                              <form class="" action="" method="post">
                                <select id="curso" name="curso">
                                      <option value="0">Seleccione el curso</option>
                                      <option value="Jardín">Jardín</option>
                                      <option value="0">Pre - Escolar</option>
                                      <option value="1">1º</option>
                                      <option value="2">2º</option>
                                      <option value="3">3º</option>
                                      <option value="4">4º</option>
                                      <option value="5">5º</option>
                                      <option value="6">6º</option>
                                      <option value="7">7º</option>
                                      <option value="8">8º</option>
                                      <option value="9">9º</option>
                                       </select>
                                    <select id="encu" name="encu">
                                          <option value="0">Seleccione el estudiante</option>
                                       </select>
                               <!-- Se crea el siguiente combobox o listbox para el filtro de resultado -->

                              <br>
                                            <button name= "consulta1" type="submit">Consultar</button>
                              </form>
    <table class="table-responsive">
        <tr>
            <td><center><font color="black">Documento<font></center></td>
            <td><center><font color="black">Apellido <font></center></td>
            <td><center><font color="black">Nombre <font></center></td>
            <td><center><font color="black">Genero<font></center></td>
            <td><center><font color="black">Resultado<font></center></td>
            <td><center><font color="black">Curso<font></center></td>
        </tr>
      <?php
      if  (isset($_POST['consulta1'])){
            $dats = $conectar -> query("sELECT * FROM encuestados WHERE no_documento = '".$_POST['encu']."' ");
            while($datAp = mysqli_fetch_array($dats)){
      ?>
                  <td><center><font color="black"><?php print $datAp['no_documento']; ?></font></center></td>
                  <td><center><font color="black"><?php print $datAp['apellidos']; ?></font></center></td>
                  <td><center><font color="black"><?php print $datAp['nombres']; ?></font></center></td>
                  <td><center><font color="black"><?php print $datAp['genero']; ?></font></center></td>
                  <td><center><font color="black"><?php print $datAp['porcentaje']; ?></font></center></td>
                  <td><center><font color="black"><?php print $datAp['curso']; ?></font></center></td>
                                </tr>
             <?php  $v++;
           }
         }?>
                          </table>
                    </div>
              </div>
        </div>
  </section>

            <!-- Footer --><a href="indexCon.php">
            <font color="black"><center> Volver</center> </font>
        </a>
                  <footer id="footer">
        </a>
                        <div class="copyright">
                           <img src="../../images/LOGO-SENA.jpg">
            <br>
                              &copy; Untitled. All rights reserved.
                              <h6 align="center">
        <a href="destrucciontotal.php">
            <font color="black"> Cerrar Sesion </font>
        </a>

    </h6>
                        </div>
                  </footer>

            <!-- Scripts -->
                  <script src="../../assets/js/jquery.min.js"></script>
                  <script src="../../assets/js/jquery.scrollex.min.js"></script>
                  <script src="../../assets/js/skel.min.js"></script>
                  <script src="../../assets/js/util.js"></script>
                  <script src="../../assets/js/main.js"></script>

      </body>
</html>
