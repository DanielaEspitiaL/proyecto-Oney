<?php
      
    if(!isset($_SESSION)){ 
    	session_start();
	    
	    if($_SESSION['coor']<>true){
	          header("Location: ../../Logins/ConLog.php?error=4");
	    }}
      
?>