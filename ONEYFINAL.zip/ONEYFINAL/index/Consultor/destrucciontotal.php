<?php 
session_start();
session_destroy();
header('Location: ../../Logins/ConLog.php');
exit;

?>