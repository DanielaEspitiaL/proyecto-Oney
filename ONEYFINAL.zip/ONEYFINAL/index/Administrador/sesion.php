<?php
      
    if(!isset($_SESSION)){ 
    	session_start();
	    
	    if($_SESSION['conexion']<>true){
	          header("Location: ../../Logins/AdmLog.php?error=4");
	    }}
      
?>