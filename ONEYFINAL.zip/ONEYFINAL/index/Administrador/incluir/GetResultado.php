<!DOCTYPE html>
<?php
      require ('../../../conexion.php');
      //  Se recibe el id de la competencia y se almacena en una variable
      $idC = $_POST['codigo_competencia'];
      // Se realiza la consulta a la base de datos para traer todos los resultados que pertenecen a la competencia
      // seleccionada
      $queryR="SELECT codigo_resultado, descripcion_resultado
       FROM resultado WHERE codigo_competencia = $idC
      ORDER BY descripcion_resultado ASC";
      $resR = $conectar->query($queryR);
      $resul="<option value='null'>Seleccione un resultado</option>";
      // Los datos recibidos de la base de datos se almacenan en un array y luego se imprimen en el combobox o listbox
      while($resultados = mysqli_fetch_array($resR)){
            print  $resul;
            $resul = "<option value='".$resultados['codigo_resultado']."'>".$resultados['descripcion_resultado'].
            "</option>";

            }
// Se imprimen los datos almacenados en la variable
      print  $resul;
?>
