<!DOCTYPE html>
<?php
      require ('../../../conexion.php');
      //  Se recibe el id de la competencia y se almacena en una variable
      $Datos = $_POST['id_instructor'];
      $vector1 = explode(';', $Datos);
      $idI= $vector1['0'];
      $idA= $vector1['1'];
      // Se realiza la consulta a la base de datos para traer todos los resultados que pertenecen a la competencia
      // seleccionada
      $queryA1="SELECT actividad.codigo_actividad, actividad.descripcion_actividad
      FROM descripcion INNER JOIN actividad
      on descripcion.codigo_actividad = actividad.codigo_actividad
      and descripcion.id_aprendiz=$idA
      and descripcion.id_instructor=$idI
      ORDER BY actividad.descripcion_actividad ASC";
      $resA1 = $conectar->query($queryA1);
      $acti="<option value='null'>Seleccione una actividad</option>";
      // Los datos recibidos de la base de datos se almacenan en un array y luego se imprimen en el combobox o listbox
      while($actividades = mysqli_fetch_array($resA1)){
            print  $acti;
            $acti= "<option value='".$actividades['codigo_actividad']."'>".$actividades['descripcion_actividad'].
            "</option>";
            }
// Se imprimen los datos almacenados en la variable
      print  $acti;
?>
