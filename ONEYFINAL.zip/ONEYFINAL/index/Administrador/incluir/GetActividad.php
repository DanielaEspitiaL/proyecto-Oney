<!DOCTYPE html>
<?php
      require ('../../../conexion.php');
      //  Se recibe el id de la competencia y se almacena en una variable
      $idR = $_POST['codigo_resultado'];
      // Se realiza la consulta a la base de datos para traer todos los resultados que pertenecen a la competencia
      // seleccionada
      $queryA="SELECT codigo_actividad, descripcion_actividad
      FROM actividad WHERE codigo_resultado = $idR
      ORDER BY descripcion_actividad ASC";
      $resA = $conectar->query($queryA);
      $acti="<option value='null'>Seleccione una actividad</option>";
      // Los datos recibidos de la base de datos se almacenan en un array y luego se imprimen en el combobox o listbox
      while($actividades = mysqli_fetch_array($resA)){
            print  $acti;
            $acti= "<option value='".$actividades['codigo_actividad']."'>".$actividades['descripcion_actividad'].
            "</option>";
            }
// Se imprimen los datos almacenados en la variable
      print  $acti;
?>
