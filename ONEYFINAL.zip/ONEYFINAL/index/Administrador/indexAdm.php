<!DOCTYPE html>
<?php
require ('../../conexion.php');
include ("sesion.php");
?>
<html>
      <head>
            <title>ONEY</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <link rel="shortcut icon" type="image/png" href="../../images/SVE1.png">
            <link rel="stylesheet" href="../../assets/css/main.css" />
            <link rel="stylesheet" href="../../assets/css/bootstrap.css" />

      </head>
      <body class="subpage">
                  <section id="One" class="wrapper style3">
                        <div class="inner">
                              <header class="align-center">
                                <center><a ><img src="../../images/SVE1.png"></a></center>
                              </header>
                        </div>
                  </section>

<!-- Two -->
  <section id="two" class="wrapper style2">
        <div class="inner">
              <div class="box">
                    <div class="content">
                        <header class="align-center">
                                <h1>Bienvenido Administrador</h1>
                                <br>
                        </header>
                            <table class="table-responsive">
                                <tr>
                                <form name="form1" action="../Administrador/Usuarios/IndexUsuAdm.php" enctype="multipart/form-data" method="post">
                                <td colspan="2"><center><input type="submit" name="btn" value="Usuarios"></center></td>
                                </form>
                                </tr>
                            </table>                                         
                    </div>
              </div>
        </div>
  </section>

            <!-- Footer -->
                  <footer id="footer">
                        <div class="copyright">
                           <img src="../../images/LOGO-SENA.jpg">
            <br>
                              &copy; Untitled. All rights reserved.
                              <h6 align="center">
        <a class="table2" href="destrucciontotal.php">

            <font color="black">Cerrar Sesion </font>
        </a>

    </h6>
                        </div>
                  </footer>

            <!-- Scripts -->
                  <script src="../../assets/js/jquery.min.js"></script>
                  <script src="../../assets/js/jquery.scrollex.min.js"></script>
                  <script src="../../assets/js/skel.min.js"></script>
                  <script src="../../assets/js/util.js"></script>
                  <script src="../../assets/js/main.js"></script>

      </body>
</html> 
