<?php
$accion=$_REQUEST['accion'];

$cnx=new PDO("mysql:host=localhost;dbname=oney","root","");

switch ($accion){
    case 'insertar':
        $nombres=$_REQUEST['txtNombres'];
        $apellidos=$_REQUEST['txtApellidos'];
        $tipoident=$_REQUEST['txtTipIdentificacion'];
        $identificacion=$_REQUEST['txtIdentificacion'];
        $ocupacion=$_REQUEST['txtOcupacion'];
        $institucion=$_REQUEST['txtInstitucion'];
        $correo=$_REQUEST['txtCorreo'];
        $telefono=$_REQUEST['txtTelefono'];
        $region=$_REQUEST['txtRegion'];
        $estadocivil=$_REQUEST['txtEstadoCivil'];
        $estado=$_REQUEST['txtEstado'];
        $rol=$_REQUEST['txtRol'];
        $usuario=$_REQUEST['txtUsuario'];
        $contraseña=$_REQUEST['txtContraseña'];


        $res = $cnx->query("insert into administrador values (null,'$nombres', '$apellidos','$tipoident','$identificacion','$ocupacion','$institucion','$correo','$telefono','$region','$estadocivil','$usuario','$contraseña','$contraseña','$estado','$rol')");
        break;

    case 'eliminar':
        $id=$_REQUEST['id'];
        $res = $cnx->query("delete from administrador where id=$id");
        break;

    case 'editar':
        $id=$_REQUEST['txtId'];
        $nombres=$_REQUEST['txtNombres'];
        $apellidos=$_REQUEST['txtApellidos'];
        $tipoident=$_REQUEST['txtTipIdentificacion'];
        $identificacion=$_REQUEST['txtIdentificacion'];
        $ocupacion=$_REQUEST['txtOcupacion'];
        $institucion=$_REQUEST['txtInstitucion'];
        $correo=$_REQUEST['txtCorreo'];
        $telefono=$_REQUEST['txtTelefono'];
        $region=$_REQUEST['txtRegion'];
        $estadocivil=$_REQUEST['txtEstadoCivil'];
        $usuario=$_REQUEST['txtUsuario'];
        $contraseña=$_REQUEST['txtContraseña'];
        $estado=$_REQUEST['txtEstado'];
        $rol=$_REQUEST['txtRol'];

        $res = $cnx->query(
            "update administrador set nombres='$nombres', apellidos='$apellidos', tipo_identificacion='$tipoident' , identificacion='$identificacion' , ocupacion='$ocupacion' , institucion='$institucion' , correo='$correo' , telefono='$telefono' , region='$region' , estado_civil='$estadocivil' , usuario='$usuario' , clave='$contraseña' , clave2='$contraseña', estado='$estado' , rol='$rol' where id='$id'");
        break;
}
$cnx=null;
header("Location: IndexUsuAdm.php");
?>
