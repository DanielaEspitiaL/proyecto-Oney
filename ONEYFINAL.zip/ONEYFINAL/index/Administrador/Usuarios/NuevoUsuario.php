<!DOCTYPE html>
<?php
?>
<html>
      <head>
            <title>ONEY</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <link rel="stylesheet" href="../../../assets/css/main.css" />
            <link rel="stylesheet" href="../../../assets/css/bootstrap.css" />

      </head>
      <body class="subpage">
                  <section id="One" class="wrapper style3">
                        <div class="inner">
                              <header class="align-center">
                                <center><a href="VSE.php"><img src="../../../images/SVE1.png"></a></center>
                              </header>
                        </div>
                  </section>

<!-- Two -->
  <section id="two" class="wrapper style2">
        <div class="inner">
              <div class="box">
                    <div class="content">
                        <header class="align-center">
                                <h1><b><i>Agregar Usuario</i></b></h1>
                                <br>
                        </header>

<form name="form1" action="ValidaUsuarios.php" enctype="multipart/form-data" method="post">
            <table border="10" width="100" align="center" >
               <tr>
                    <td align="center"><font color="black">Nombres:</font> </td>
                    <td><input type="text" name="txtNombres"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Apellidos:</font></td>
                    <td><input type="text" name="txtApellidos"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Tipo Identificación:</font></td>
                    <td><input type="text" name="txtTipIdentificacion"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Identificación:</font></td>
                    <td><input type="text" name="txtIdentificacion"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Ocupación:</font></td>
                    <td><input type="text" name="txtOcupacion"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Institución:</font></td>
                    <td><input type="text" name="txtInstitucion"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Correo:</font></td>
                    <td><input type="text" name="txtCorreo"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Telefono:</font></td>
                    <td><input type="text" name="txtTelefono"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Región(Ciudad):</font></td>
                    <td><input type="text" name="txtRegion"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Estado Civil:</font></td>
                    <td><input type="text" name="txtEstadoCivil"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Estado:</font></td>
                    <td><input type="text" name="txtEstado"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Rol:</font></td>
                    <td><input type="text" name="txtRol"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Usuario:</font></td>
                    <td><input type="text" name="txtUsuario"></td>
                </tr>
                <tr>
                    <td align="center"><font color="black">Contraseña:</font></td>
                    <td><input type="text" name="txtContraseña"></td>
                </tr>
                <tr>
                      <td colspan="2"><center><input type="submit" name="btn" value="Guardar Registro"></center></td>
                </tr>
            </table>
                <a class="" href="IndexUsuAdm.php"> <center>Volver</center></a>
            <input type="hidden" name=accion value=insertar>
        </form>

                </div>
            </div>
        </div>
  </section>
            <!-- Footer -->
                  <footer id="footer">
                        <div class="copyright">
                           <img src="../../../images/LOGO-SENA.jpg">
            <br>
                              &copy; Untitled. All rights reserved.
                              <h6 align="center">
        <a  href="../../../Logins/AdmLog.php">
            <font color="black"> Cerrar Sesion </font>
        </a>

    </h6>
                        </div>
                  </footer>

            <!-- Scripts -->
                  <script src="../../../assets/js/jquery.min.js"></script>
                  <script src="../../../assets/js/jquery.scrollex.min.js"></script>
                  <script src="../../../assets/js/skel.min.js"></script>
                  <script src="../../../assets/js/util.js"></script>
                  <script src="../../../assets/js/main.js"></script>

      </body>
</html>
