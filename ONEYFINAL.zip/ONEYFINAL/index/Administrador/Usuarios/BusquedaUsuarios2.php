<!DOCTYPE html>
<html>
<head>
            <title>Administradores</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <link rel="stylesheet" href="../../../assets/css/main.css" />
            <link rel="stylesheet" href="../../../assets/css/bootstrap.css" />
</head>
<body class="subpage">
            <section id="One" class="wrapper style3">
            <div class="inner">
            <header class="align-center">
            <center><a href="VSE.php"><img src="../../../images/SVE1.png"></a></center>
            </header>
            </div>
            </section>
  <section id="two" class="wrapper style2">
            <div class="inner">
            <div class="box">
            <div class="content">
            <header class="align-center">
            <h1><b><i>Modificación Usuarios</i></b></h1>
            <br>
            </header>
  <section>
      <?php
        $id=$_REQUEST['id'];
         $cnx=new PDO("mysql:host=localhost;dbname=oney","root","");
            $res = $cnx->query("select * from administrador where id=$id");
      ?>
    <form action="ValidaUsuarios.php" method="POST">
    <table class="table">
      <?php
            foreach ($res as $row)
            {
      ?>
                <input type="hidden" name="txtId" value="<?php echo $row[0]; ?>">
                <tr>
                    <td>Nombres</td>
                    <td><input type="text" name="txtNombres" value="<?php echo $row[1]; ?>"></td>
                </tr><tr>
                    <td>Apellidos</td>
                    <td><input type="text" name="txtApellidos" value="<?php echo $row[2]; ?>"></td>
                </tr><tr>
                    <td>Tipo de identificación</td>
                    <td><input type="text" name="txtTipIdentificacion" value="<?php echo $row[3]; ?>"></td>
                </tr><tr>
                    <td>Identificación</td>
                    <td><input type="text" name="txtIdentificacion" value="<?php echo $row[4]; ?>"></td>
                </tr><tr>
                    <td>Ocupación</td>
                    <td><input type="text" name="txtOcupacion" value="<?php echo $row[5]; ?>"></td>
                </tr><tr>
                    <td>Institución</td>
                    <td><input type="text" name="txtInstitucion" value="<?php echo $row[6]; ?>"></td>
                </tr><tr>
                    <td>Correo</td>
                    <td><input type="text" name="txtCorreo" value="<?php echo $row[7]; ?>"></td>
                </tr><tr>
                    <td>Telefono</td>
                    <td><input type="text" name="txtTelefono" value="<?php echo $row[8]; ?>"></td>
                </tr><tr>
                    <td>Región(Ciudad)</td>
                    <td><input type="text" name="txtRegion" value="<?php echo $row[9]; ?>"></td>
                </tr><tr>
                    <td>Estado Civil</td>
                    <td><input type="text" name="txtEstadoCivil" value="<?php echo $row[10]; ?>"></td>
                </tr><tr>
                    <td>Estado</td>
                    <td><input type="text" name="txtEstado" value="<?php echo $row[14]; ?>"></td>
                </tr><tr>
                    <td>Rol</td>
                    <td><input type="text" name="txtRol" value="<?php echo $row[15]; ?>"></td>
                </tr><tr>
                    <td>Usuario</td>
                    <td><input type="text" name="txtUsuario" value="<?php echo $row[11]; ?>"></td>
                </tr><tr>
                    <td>Clave</td>
                    <td><input type="text" name="txtContraseña" value="<?php echo $row[12]; ?>"></td>
                </tr>
      <?php
            }
                ?>
            </table>
            <td colspan="2"><center><input type="submit" name="btn" value="Actualizar Registro"></center>
            <input type="hidden" name=accion value=editar>
    <?
    echo $mensaje;
    ?>
  </section>
              <!-- Scripts -->
                  <script src="../../../assets/js/jquery.min.js"></script>
                  <script src="../../../assets/js/jquery.scrollex.min.js"></script>
                  <script src="../../../assets/js/skel.min.js"></script>
                  <script src="../../../assets/js/util.js"></script>
                  <script src="../../../assets/js/main.js"></script>
</form>
</body>
</html>
