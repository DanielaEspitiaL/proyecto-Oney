<!DOCTYPE html>
<?php
?>
<html>
      <head>
            <title>ONEY</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <link rel="stylesheet" href="../../assets/css/main.css" />
            <link rel="stylesheet" href="../../assets/css/bootstrap.css" />

      </head>
      <body class="subpage">
                  <section id="One" class="wrapper style3">
                        <div class="inner">
                              <header class="align-center">
                                <center><a href="VSE.php"><img src="../../images/SVE1.png"></a></center>
                              </header>
                        </div>
                  </section>

<!-- Two -->
  <section id="two" class="wrapper style2">
        <div class="inner">
              <div class="box">
                    <div class="content">
                        <header class="align-center">
                                <h1><b><i>Prevención abuso sexual infantil</i></b></h1>
                                <br>
                                <br>
                                <h4><b><i>Por favor responda el cuestionario de acuerdo al comportamiento del encuestado</i></b></h4>
                        </header>

<form name="form1" action="ValidaResultado.php" enctype="multipart/form-data" method="post">
            <table border="10" width="100" align="center" >
              <tr>
                   <td align="center"><font color="black">1.¿El niño presenta alguna marca de moretones, raspaduras, mal formaciones o cualquier herida que denote algún tipo de descuido con su integridad personal?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R1"></input>
                       <option value="1">Si</option>
                       <option value="0" selected="selected">No</option>
                       </select></td>
               </tr>
               <tr>
                    <td align="center"><font color="black"></font> </td>
                </tr>
                <tr>
                     <td align="center"><font color="black">2.¿Al niño le cuesta conciliar el sueño, tiene dificultad para caminar o sentarse o se rehúsa a realizar alguna actividad que requiera un esfuerzo físico?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R2"></input>
                       <option value="1">Si</option>
                       <option value="0" selected="selected">No</option>
                         </select></td>
                 </tr>
                 <tr>
                      <td align="center"><font color="black"></font> </td>
                  </tr>
                  <tr>
                       <td align="center"><font color="black">3.¿Demuestra comportamiento extremo, como quejarse mucho o ser muy exigente, extremadamente pasivo o agresivo. Actúa inapropiadamente como un adulto (por ejemplo aconsejando a otros niños,) o inapropiadamente infantil (por ejemplo, meciéndose o pegando su cabeza en contra de algo)?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R3"></input>
                           <option value="1">Si</option>
                           <option value="0" selected="selected">No</option>
                           </select></td>
                   </tr>
                   <tr>
                        <td align="center"><font color="black"></font> </td>
                   </tr>
                   <tr>
                         <td align="center"><font color="black">4.¿Demuestra cambios repentinos en el comportamiento o sus calificaciones, Tiene problemas de aprendizaje (deficit de atención) que no se pueden
                                                                atribuir específicamente a causas físicas o psicológicas o constantemente se muestra alerta, a la expectativa de que algo malo le pueda ocurrir?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R4"></input>
                             <option value="1">Si</option>
                             <option value="0" selected="selected">No</option>
                             </select></td>
                    </tr>
                    <tr>
                         <td align="center"><font color="black"></font> </td>
                    </tr>
                    <tr>
                          <td align="center"><font color="black">5.¿Asiste a la escuela y/o a otras actividades mas temprano de lo habitual, se queda tarde o no quiere regresar a su casa?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R5"></input>
                              <option value="1">Si</option>
                              <option value="0" selected="selected">No</option>
                              </select></td>
                     </tr>
                     <tr>
                          <td align="center"><font color="black"></font> </td>
                     </tr>
                     <tr>
                           <td align="center"><font color="black">6.¿Se puede notar como no se interesa socialmente por compartir intereses con sus compañeros, se ve constantemente alejado, excluido o muy introvertido?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R6"></input>
                               <option value="1" align="center">Si</option>
                               <option value="0" align="center" selected="selected">No</option>
                               </select></td>
                      </tr>
                      <tr>
                           <td align="center"><font color="black"></font> </td>
                      </tr>
                      <tr>
                            <td align="center"><font color="black">7.¿El niño muestra, dibuja o imita conductas sexuales adultas?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R7"></input>
                                <option value="1" align="center">Si</option>
                                <option value="0" align="center" selected="selected">No</option>
                                </select></td>
                       </tr>
                       <tr>
                            <td align="center"><font color="black"></font> </td>
                       </tr>
                       <tr>
                             <td align="center"><font color="black">8.¿El niño muestra un cambio repentino en el aumento o disminución de su apetito?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R8"></input>
                                 <option value="1" align="center">Si</option>
                                 <option value="0" align="center" selected="selected">No</option>
                                 </select></td>
                        </tr>
                        <tr>
                             <td align="center"><font color="black"></font> </td>
                        </tr>
                        <tr>
                              <td align="center"><font color="black">9.¿El niño presenta lesiones o infecciones genitales?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R9"></input>
                                  <option value="1" align="center">Si</option>
                                  <option value="0" align="center" selected="selected">No</option>
                                  </select></td>
                         </tr>
                         <tr>
                              <td align="center"><font color="black"></font> </td>
                         </tr>
                         <tr>
                               <td align="center"><font color="black">10.¿El niño comenzó a vestir diferente y/o a descuidar su higiene personal?</font> </td>
                   <td><input type="hidden"><select style="width : 45px; heigth : 1px" name="R10"></input>
                                   <option value="1" align="center">Si</option>
                                   <option value="0" align="center" selected="selected">No</option>
                                   </select></td>
                          </tr>
                <tr>
                      <td colspan="2"><center><input type="submit" name="btn" value="Guardar Cuestionario"></center></td>
                </tr>
            </table>
                <a class="" href="indexInstructor.php"> <center>Volver</center></a>
            <input type="hidden" name=accion value=insertar>
        </form>

                </div>
            </div>
        </div>
  </section>
            <!-- Footer -->
                  <footer id="footer">
                        <div class="copyright">
                           <img src="../../images/LOGO-SENA.jpg">
            <br>
                              &copy; Untitled. All rights reserved.
                              <h6 align="center">
        <a  href="../../Logins/AdmLog1.php">
            <font color="black"> Cerrar Sesion </font>
        </a>

    </h6>
                        </div>
                  </footer>

            <!-- Scripts -->
                  <script src="../../assets/js/jquery.min.js"></script>
                  <script src="../../assets/js/jquery.scrollex.min.js"></script>
                  <script src="../../assets/js/skel.min.js"></script>
                  <script src="../../assets/js/util.js"></script>
                  <script src="../../assets/js/main.js"></script>

      </body>
</html>
