<?php
//----- CONEXION A LA BASE DE DATOS -----//
$host="localhost";
$usuario="root";
$contraseña="";
$base="oney";

$conexion = new mysqli($host, $usuario, $contraseña, $base);
if ($conexion -> connect_errno)
{
  die("Fallo la conexion:(".$conexion -> mysqli_connect_errno().")".$conexion-> mysqli_connect_error());
}


//----- VARIABLES DE CONSULTA -----//
error_reporting(0);
$where="";
$limit = $_REQUEST['xregistros'];
////////////////////// BOTON BUSCAR //////////////////////////////////////

if (isset($_REQUEST['buscar']))
{
  // Algunos de los datos que recibia estaban cruzados
  $idAdm=$_REQUEST['idAdm'];
  $nomAdm=$_REQUEST['nomAdm'];
  $apeAdm=$_REQUEST['apeAdm'];
  $ideAdm=$_REQUEST['ideAdm'];
  $usuAdm=$_REQUEST['usuAdm'];
  echo $idAdm;
  echo $nomAdm;
  echo $ApeAdm;
  echo $usuAdm;

  //  A todos los EMPTY los cambia por !EMPTY para que le funcione la consulta por filtros
  if (!empty($_REQUEST['idAdm']))
  {
  // AQUÍ TENIA $_REQUEST_['xcarrera'] -- YO la cabié por xnombre...
    $where="where id = '".$idAdm."%'";
  }

  else if (!empty($_REQUEST['nomAdm']))
  {
    $where="where nombres like '".$nomAdm."%'";
  }
  else if (!empty($_REQUEST['apeAdm']))
  {
    $where="where apellidos like'".$apeAdm."%'";
  }
    else if (!empty($_REQUEST['ideAdm']))
  {
    $where="where identificacion like'%".$ideAdm."%'";
  }
  else if (!empty($_REQUEST['usuAdm']))
  {
    $where="where usuario like '".$usuAdm."%'";
  }
}

/////////////////////// CONSULTA A LA BASE DE DATOS ////////////////////////

$consulta="SELECT * FROM administrador $where $limit";
$res=$conexion->query($consulta);
$resActividades=$conexion->query($consulta);
$resCarreras=$conexion->query($consulta);
$resCodigo=$conexion->query($consulta);
$resResultado=$conexion->query($consulta);


if(mysqli_num_rows($resActividades)==0)
{
  $mensaje="<h1>No hay registros que coincidan con su criterio de búsqueda.</h1>";
}

?>


<html lang="es">

<head>
  <title>Usuarios</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <link rel="stylesheet" href="../../assets/css/main.css" />
            <link rel="stylesheet" href="../../assets/css/bootstrap.css" />
</head>
      <body class="subpage">
                  <section id="One" class="wrapper style3">
                        <div class="inner">
                              <header class="align-center">
                                <center><a href="VSE.php"><img src="../../images/SVE1.png"></a></center>
                              </header>
                        </div>
                  </section>
  <section id="two" class="wrapper style2">
        <div class="inner">
              <div class="box">
                    <div class="content">
                         <header class="align-center">
                                <h1><b><i>Busqueda Encuestados</i></b></h1>
                                <br>
                        </header> 

                        </table>
    <table class="table">
      <tr>
        <th><center>Id</center></th>
        <th><center>Nombre</center></th>
        <th><center>Apellidos</center></th>
        <th><center>Identificación</center></th>
        <th><center>Correo</center></th>
        <th><center>Telefono</center></th>
        <th><center>Usuario</center></th>
        <th><center>Clave</center></th>
      </tr>

  <section>
<table border="10" width="100" align="center" >
    <form method="POST" action="ConsultaResultados.php">

      <input style="width : 140px; heigth : 1px" placeholder="Id" name="idAdm"/>
      <input placeholder="Nombres" name="nomAdm"/>
      <input placeholder="Apellidos" name="apeAdm"/>
      <input placeholder="Identificación" name="ideAdm"/>
      <input placeholder="Usuario" name="usuAdm"/>
      <input placeholder="documento" name="usuAdm"/>
      <input placeholder="genero" name="usuAdm"/>
      <input placeholder="porcentaje" name="usuAdm"/>
      <input placeholder="curso" name="usuAdm"/>

<!-- Si recibe los limites y los ejecuta correctamente... -->
      <center>
        <option value="">No. de Registros</option>
        <select name="xregistros" style="width : 200px; heigth : 1px">
        <option value="limit 2">2</option>
        <option value="limit 5">5</option>
        <option value="limit 10">10</option>
        <option value="limit 15">15</option>
        <option value="limit 20">20</option>
        <option value="limit 25">25</option>
        </select>
        <button name="buscar" type="submit">Buscar</button>
      </center>
    </form>


    <?php
            $cnx=new PDO("mysql:host=localhost;dbname=oney","root","");
            $res = $cnx->query("select * from encuestados $where $limit");
             foreach ($res as $row)
            {
            ?>
            <tr>
                <td><center><?php echo $row[0]; ?></center></td>
                <td><center><?php echo $row[1]; ?></center></td>
                <td><center><?php echo $row[2]; ?></center></td>
                <td><center><?php echo $row[4]; ?></center></td>
                <td><center><?php echo $row[7]; ?></center></td>
                <td><center><?php echo $row[8]; ?></center></td>
                <td><center><?php echo $row[11]; ?></center></td>
                <td><center><?php echo $row[12]; ?></center></td>
            </tr>
       <?php
        }
            ?>

    </table>
                    <a class="" href="indexUsuario.php"> <center>Volver</center></a>

    <?
    echo $mensaje;
    ?>
  </section>
                   <footer id="footer">
                        <div class="copyright">
                           <img src="../../images/LOGO-SENA.jpg">
            <br>
                              &copy; Untitled. All rights reserved.
                              <h6 align="center">
        <a  href="../../Logins/ConLog.php">
            <font color="black"> Cerrar Sesion </font>
        </a>

    </h6>
                        </div>
                  </footer>
              <!-- Scripts -->
                  <script src="../../assets/js/jquery.min.js"></script>
                  <script src="../../assets/js/jquery.scrollex.min.js"></script>
                  <script src="../../assets/js/skel.min.js"></script>
                  <script src="../../assets/js/util.js"></script>
                  <script src="../../assets/js/main.js"></script>

</body>
</html>
