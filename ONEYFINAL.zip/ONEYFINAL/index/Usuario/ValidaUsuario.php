<?php
$accion=$_REQUEST['accion'];

$cnx=new PDO("mysql:host=localhost;dbname=oney","root","");

switch ($accion){
    case 'insertar':
        $idenc=$_REQUEST['txtIdEnc'];
        $nombres=$_REQUEST['txtNombres'];
        $apellidos=$_REQUEST['txtApellidos'];
        $tipident=$_REQUEST['txtTipIdentificacion'];
        $identificacion=$_REQUEST['txtIdentificacion'];
        $genero=$_REQUEST['txtGenero'];
        $encuesta=$_REQUEST['txtEncuesta'];
        $resultado=$_REQUEST['txtResultado'];
        $grado=$_REQUEST['txtGrado'];
        $fecha=$_REQUEST['txtFecha'];
        $edad=$_REQUEST['txtEdad'];
        $res = $cnx->query("insert into encuestados values (null, '$idenc','$nombres', '$apellidos','$tipident','$identificacion','$genero','$encuesta','$resultado','$grado','$fecha','$edad')");

        $cnx=null;
        header("Location: getResultado.php");

    case 'eliminar':
        $cod=$_REQUEST['cod'];
        $res = $cnx->query("delete from instructor where id_instructor=$cod");
        break;

    case 'editar':
        $cod=$_REQUEST['txtIdentificacion'];
        $nombre_instructor=$_REQUEST['txtNombre'];
        $apellido_instructor=$_REQUEST['txtApellido'];
        $correo_instructor=$_REQUEST['txtCorreo'];
        $password_instructor=$_REQUEST['txtPassword'];

        $res = $cnx->query("update instructor set id_instructor = $cod, nombre_instructor='$nombre_instructor',  apellido_instructor='$apellido_instructor', correo_instructor='$correo_instructor' , password_instructor='$password_instructor' where id_instructor=$cod");
        break;
}
$cnx=null;
header("Location: IndexUsuario.php");
?>
