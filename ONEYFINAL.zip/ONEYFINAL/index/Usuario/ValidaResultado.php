<?php
$accion=$_REQUEST['accion'];

$cnx=new PDO("mysql:host=localhost;dbname=oney","root","");

$R1 = $_POST["R1"];
$R2 = $_POST["R2"];
$R3 = $_POST["R3"];
$R4 = $_POST["R4"];
$R5 = $_POST["R5"];
$R6 = $_POST["R6"];
$R7 = $_POST["R7"];
$R8 = $_POST["R8"];
$R9 = $_POST["R9"];
$R10 = $_POST["R10"];

$RFinal = $R1+$R2+$R3+$R4+$R5+$R6+$R7+$R8+$R9+$R10;

//ejecutar consulta con la base de datos

 if ($RFinal>=6) {

echo'<script>alert("El paciente se encuentra en grave riesgo de padecer una incidencia de abuso sexual");
    window.history.go(-1);
    </script>';

header("Location: interfaz_critica.html");

}else if ($RFinal>=4)  {

echo'<script>alert("El paciente no se encuentra en grave riesgo de padecer una incidencia de abuso sexual, pero requiere de una vigilancia especial");
    window.history.go(-1);
    </script>';

header("Location: interfaz_media.html");

}else if ($RFinal>=2) {

echo'<script>alert("El paciente no presenta ningún riesgo de padecer una incidencia de abuso sexual");
    window.history.go(-1);
    </script>';

header("Location: interfaz_bueno.html");
}
$cnx=null;
?>
