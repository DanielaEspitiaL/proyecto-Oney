<?php
      // Se incluye el archivo de conexión a la base de datos.
      include ("conexion.php");

      // Se almacenan los datos recibidos en constantes.
      $usser = $_POST['usercod'];
      $password =$_POST['passcod'];

if(isset($_POST['usercod']) and isset($_POST['passcod'])){
      if (empty($_POST['usercod']) or empty($_POST['passcod']) ){
         header('location: Logins/ConLog.php?error=1');

      } else {

            try {
            // Se realiza la consulta en la base de datos.
                  $result = $conectar -> query ("select * from administrador where usuario = '$usser' and clave = '$password' and rol = 'Consultor'");
            $num = mysqli_num_rows($result);
            $li=mysqli_fetch_array($result);
            $id=$li['identificacion'];
            // Se verifica que los datos estén correctos y se en cuentran en la base de datos.
      	if($num > 0) {
      		session_start();
               $_SESSION['coor'] = true;
               $_SESSION['idcoo'] = $id;
                  header('location: index/Consultor/indexCon.php');
      	}else {
      		    header('location: Logins/ConLog.php?error=2');
      	}
      } catch (Exception $e) {
            echo $e;
      }
      }
}else{
   header('location: Logins/ConLog.php?error=3');
}



?>
