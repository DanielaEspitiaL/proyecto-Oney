-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 16-11-2019 a las 19:32:18
-- Versión del servidor: 10.3.16-MariaDB
-- Versión de PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `id11135452_oney`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `id` int(11) NOT NULL,
  `nombres` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellidos` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo_identificacion` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `identificacion` int(15) DEFAULT NULL,
  `ocupacion` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `institucion` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `correo` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `region` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado_civil` varchar(26) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `clave` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `clave2` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `rol` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `administrador`
--

INSERT INTO `administrador` (`id`, `nombres`, `apellidos`, `tipo_identificacion`, `identificacion`, `ocupacion`, `institucion`, `correo`, `telefono`, `region`, `estado_civil`, `usuario`, `clave`, `clave2`, `estado`, `rol`) VALUES
(2, 'a', 'b', 'dasd', 9887879, 'sahkdashkj|', 'asdhsadhsjkadh', 'asldkjaskl@hotmail.com', '23432|', 'dadkjasdlksajdl', 'alkdjas', 'dasdjaskldj', '321', '321', '', ''),
(4, 'johan', 'peralta', 'C.C', 1010013463, 'estudiante', 'politecnico', 'jogan34343@gmail.com', '3188882214', 'bogota', 'Soltero/a', 'jperalta', '321', '321', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta`
--

CREATE TABLE `encuesta` (
  `id` int(11) NOT NULL,
  `pregunta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `encuesta` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuestados`
--

CREATE TABLE `encuestados` (
  `id` int(11) NOT NULL,
  `nombres` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellidos` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo_identificacion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_documento` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `genero` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_encuesta` int(11) DEFAULT NULL,
  `porcentaje` decimal(10,0) DEFAULT NULL,
  `curso` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_actua` date DEFAULT NULL,
  `edad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuesta`
--

CREATE TABLE `respuesta` (
  `id` int(11) NOT NULL,
  `respuesta` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `id_encuestado` int(11) NOT NULL,
  `id_pregunta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `encuesta`
--
ALTER TABLE `encuesta`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `encuestados`
--
ALTER TABLE `encuestados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `respuesta`
--
ALTER TABLE `respuesta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `encuestado_fk` (`id_encuestado`),
  ADD KEY `pregunta_fk` (`id_pregunta`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administrador`
--
ALTER TABLE `administrador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `encuesta`
--
ALTER TABLE `encuesta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `encuestados`
--
ALTER TABLE `encuestados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `respuesta`
--
ALTER TABLE `respuesta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
