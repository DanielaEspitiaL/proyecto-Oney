<?php

            //requisitos de la conexión - atributos de la clase
      $Servidor = "localhost";
      $Usuario = "root";
      $Password = "";
      $Database = "oney";

      // Estableciendo la conexión
            try {
                  $conectar = mysqli_connect($Servidor, $Usuario, $Password, $Database);
                  if ($conectar){
                        $conect = "conexion establecida";
                        //echo $conect;
                  }else {
                        $conect = "Fallo al realizar la conexión";
                        //echo $conect;
                  }
            }
            catch (Exception $e) {

                  die( print_r( $e->getMessage() ) );
            }


?>
