﻿<!DOCTYPE html>
<html>
<head>
    <title>ONEY</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/png" href="images/SVE1.png">
    <link rel="stylesheet" href="assets/css/main.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcsn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
    <!-- Header -->
    <header id="header" class="alt">
        <div class="logo"><a href="VSE.php"><img src="images/SVE1.png"></a></div>
        <a href="#menu">Menu</a>
    </header>
    <!-- Nav -->
    <nav id="menu">
        <ul class="links">
            <li><a href="Logins/AdmLog.php"><font color="#000">Administrador</font></a></li>
            <li><a href="Logins/UsuLog.php"><font color="#000">Usuario</font></a></li>
            <li><a href="Logins/ConLog.php"><font color="#000">Consultor</font></a></li>
        </ul>
    </nav>

    <!-- Banner -->
    <section class="banner full">
        <article>
            <img src="images/1.jpg" alt="" />
            <div class="inner">
                <header>
                    <h2><a href="aritmeticos.php"></a></h2>
                </header>
            </div>
        </article>
        <article>
            <img src="images/2.jpg" alt="" />
            <div class="inner">
                <header>
                    <h2><a href="foreach.php"></a></h2>
                </header>
            </div>
        </article>
        <article>
            <img src="images/3.jpg" alt="" />
            <div class="inner">
                <header>
                    <h2><a href="funciones.php"></a></h2>
                </header>
            </div>
        </article>
        <article>
            <img src="images/4.jpg" alt="" />
            <div class="inner">
                <header>
                    <h2></h2>
                </header>
            </div>
        </article>
        <article>
            <img src="images/5.jpg" alt="" />
            <div class="inner">
                <header>
                    <h2></h2>
                </header>
            </div>
        </article>
        <article>
            <img src="images/6.jpg" alt="" />
            <div class="inner">
                <header>
                    <h2></h2>
                </header>
            </div>
        </article>
        <article>
            <img src="images/8.jpg" alt="" />
            <div class="inner">
                <header>
                    <h2></h2>
                </header>
            </div>
        </article>
    </section>
    <!-- One -->
    <!-- Footer -->
    <footer id="footer">
        <br></br><br></br><br></br><br></br><br></br>
        <div class="copyright">
            <img src="images/LOGO-SENA.jpg">
            <br>
            &copy; Untitled. All rights reserved.
        </div>
    </footer>
    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/skel.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
